CREATE DATABASE IF NOT EXISTS `pt02_joan_diaz`;

USE `pt02_joan_diaz`;

CREATE TABLE articles(
    id INT PRIMARY KEY AUTO_INCREMENT,
    titol VARCHAR(50),
    cos TEXT
);