<?php

require_once __DIR__ . '/Controller/Article/article.controller.php';

?>
