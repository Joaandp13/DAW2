<?php
require_once __DIR__ . '/../../Model/article.model.php';

$art_ppagina = 5;
$pagina = 1;

if (isset($_GET['page']) && is_string($_GET['page'])) {
    $valor = filter_var($_GET['page'], FILTER_VALIDATE_INT);
    if ($valor !== false && $valor >= 1) {
        $pagina = $valor;
    }
}

try {
    $model = new Article();

    $total = $model->comptarArticles();
    if ($total === 0) {
        header('Location: index.php');
        exit;
    }

    $total_pagines = (int) ceil($total / $art_ppagina);
    if ($pagina > $total_pagines) {
        $pagina = $total_pagines;
    }

    $offset = ($pagina - 1) * $art_ppagina;
    $articles = $model->returnPage($art_ppagina, $offset);
} catch (PDOException $error) {
    error_log($error->getMessage());
    die("Error: " . $error->getMessage());
}

require __DIR__ . '/../../view/Article/paginacio.php';