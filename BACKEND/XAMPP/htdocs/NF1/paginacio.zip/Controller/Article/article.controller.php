


<?php

require_once __DIR__ . '/../../Model/article.model.php';

$errors = [];
$missatge = '';
$articleConsultat = false;
$articles = [];

try {
    $model = new Article();

    // Validem l’acció i les dades abans d’executar cap consulta.
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? null;

        if (!is_string($action) || !in_array($action, ['insert', 'consult', 'update', 'delete'], true)) {
            $errors[] = 'L’acció indicada no és vàlida.';
        } elseif ($action === 'consult' || $action === 'update' || $action === 'delete') {
            $idEntrada = $_POST['id'] ?? null;
            $id = is_string($idEntrada) ? filter_var($idEntrada, FILTER_VALIDATE_INT) : false;

            if ($id === false || $id < 1) {
                $errors[] = 'L’identificador ha de ser un enter positiu.';
            }
        }

        if ($errors === [] && ($action === 'insert' || $action === 'update')) {
            $titolEntrada = $_POST['titol'] ?? null;
            $cosEntrada = $_POST['cos'] ?? null;

            if (!is_string($titolEntrada) || !is_string($cosEntrada)) {
                $errors[] = 'El títol i el cos han de ser textos.';
            } else {
                $titol = trim($titolEntrada);
                $cos = trim($cosEntrada);

                if ($titol === '' || mb_strlen($titol, 'UTF-8') > 50) {
                    $errors[] = 'El títol és obligatori i no pot superar els 50 caràcters.';
                }

                if ($cos === '') {
                    $errors[] = 'El cos de l’article és obligatori.';
                }
            }
        }

        if ($errors === []) {
            if ($action === 'insert') {
                $idNou = $model->insertarNouArticle(['titol' => $titol, 'cos' => $cos]);
                $missatge = 'Article inserit correctament. ID: ' . $idNou . '.';
            } elseif ($action === 'consult') {
                $articleConsultat = $model->cercarPerId((int) $id);
                $missatge = $articleConsultat === false
                    ? 'No s’ha trobat cap article amb aquest ID.'
                    : 'Article trobat.';
            } elseif ($action === 'update') {
                $actualitzat = $model->modificarPerId((int) $id, ['titol' => $titol, 'cos' => $cos]);
                $missatge = $actualitzat
                    ? 'Article modificat correctament.'
                    : 'No s’ha trobat cap article amb aquest ID.';
            } elseif ($action === 'delete') {
                $esborrat = $model->esborrarPerId((int) $id);
                $missatge = $esborrat
                    ? 'Article esborrat correctament.'
                    : 'No s’ha trobat cap article amb aquest ID.';
            }
        } else {
            http_response_code(400);
        }
    }

    // Actualitzem el llistat després de cada operació.
    $articles = $model->llistarTots();
} catch (PDOException $error) {
    error_log('Error de base de dades en la gestió d’articles: ' . $error->getMessage());
    http_response_code(500);
    $errors[] = 'No s’ha pogut completar l’operació amb la base de dades.';
}

require __DIR__ . '/../../view/Article/insertarArticle.php';