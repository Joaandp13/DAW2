<?php

// La vista només es carrega des del controlador.
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
  header('Location: ../../index.php');
  exit;
}

?>
<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestió d’articles</title>
  <link rel="icon" href="img/skull.svg" type="image/svg+xml">
  <link rel="stylesheet" href="view/styles/style.css"> 
</head>
<body>
  <h1>Gestió d’articles</h1>

  <?php if ($missatge !== ''): ?>
    <p class="message" role="status"><?php echo htmlspecialchars($missatge, ENT_QUOTES, 'UTF-8'); ?></p>
  <?php endif; ?>

  <?php if ($errors !== []): ?>
    <ul class="errors" role="alert">
      <?php foreach ($errors as $error): ?>
        <li><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

  <h2>Inserir un article</h2>
  <form action="index.php" method="post">
    <input type="hidden" name="action" value="insert">
    <label for="titol-nou">Títol:</label>
    <input type="text" id="titol-nou" name="titol" maxlength="50" required>
    <label for="cos-nou">Cos:</label>
    <textarea id="cos-nou" name="cos" required></textarea>
    <button type="submit">Inserir article</button>
  </form>

  <h2>Cercar un article per ID</h2>
  <form action="index.php" method="post">
    <input type="hidden" name="action" value="consult">
    <label for="id-cerca">ID de l’article:</label>
    <input type="number" id="id-cerca" name="id" min="1" required>
    <button type="submit">Cercar</button>
  </form>

  <?php if ($articleConsultat !== false): ?>
    <?php if (is_array($articleConsultat)): ?>
      <section class="article-result" aria-labelledby="article-result-title">
        <h2 id="article-result-title">Article trobat</h2>
        <p><strong>ID:</strong> <?php echo htmlspecialchars((string) $articleConsultat['id'], ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Títol:</strong> <?php echo htmlspecialchars($articleConsultat['titol'], ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Cos:</strong> <?php echo nl2br(htmlspecialchars($articleConsultat['cos'], ENT_QUOTES, 'UTF-8')); ?></p>
      </section>
    <?php endif; ?>
  <?php endif; ?>

  <h2>Modificar un article</h2>
  <form action="index.php" method="post">
    <input type="hidden" name="action" value="update">
    <label for="id-modificar">ID de l’article:</label>
    <input type="number" id="id-modificar" name="id" min="1" required>
    <label for="titol-modificar">Títol nou:</label>
    <input type="text" id="titol-modificar" name="titol" maxlength="50" required>
    <label for="cos-modificar">Cos nou:</label>
    <textarea id="cos-modificar" name="cos" required></textarea>
    <button type="submit">Modificar article</button>
  </form>

  <h2>Esborrar un article</h2>
  <form action="index.php" method="post" onsubmit="return confirm('Vols esborrar aquest article?');">
    <input type="hidden" name="action" value="delete">
    <label for="id-esborrar">ID de l’article:</label>
    <input type="number" id="id-esborrar" name="id" min="1" required>
    <button type="submit">Esborrar article</button>
  </form>

  <h2>Tots els articles</h2>
  <?php if ($errors === [] && $articles === []): ?>
    <p>Encara no hi ha cap article.</p>
  <?php elseif ($articles !== []): ?>
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Títol</th>
            <th>Cos</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($articles as $article): ?>
            <tr>
              <td><?php echo htmlspecialchars((string) $article['id'], ENT_QUOTES, 'UTF-8'); ?></td>
              <td><?php echo htmlspecialchars($article['titol'], ENT_QUOTES, 'UTF-8'); ?></td>
              <td><?php echo nl2br(htmlspecialchars($article['cos'], ENT_QUOTES, 'UTF-8')); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</body>
</html>