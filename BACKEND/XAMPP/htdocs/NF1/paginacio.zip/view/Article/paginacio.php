<?php

// La vista només es carrega des del controlador.
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
  header('Location: ../../articles.php');
  exit;
}

?>
<!DOCTYPE html>
<html lang="ca">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Articles</title>
  <link rel="icon" href="img/skull.svg" type="image/svg+xml">
  <link rel="stylesheet" href="view/styles/style.css">
</head>
<body>
  <h1>Articles</h1>

  <!-- Div 1: articles de la pàgina actual -->
  <div id="articles">
    <?php foreach ($articles as $article): ?>
      <article>
        <h2><?php echo htmlspecialchars($article['titol'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <p><?php echo nl2br(htmlspecialchars($article['cos'], ENT_QUOTES, 'UTF-8')); ?></p>
      </article>
    <?php endforeach; ?>
  </div>

  <!-- Div 2: botons Anterior i Següent -->
  <div id="paginacio">
    <?php if ($pagina > 1): ?>
      <a href="articles.php?page=<?php echo $pagina - 1; ?>">Anterior</a>
    <?php else: ?>
      <span class="disabled">Anterior</span>
    <?php endif; ?>

    <span>Pàgina <?php echo $pagina; ?> de <?php echo $total_pagines; ?></span>

    <?php if ($pagina < $total_pagines): ?>
      <a href="articles.php?page=<?php echo $pagina + 1; ?>">Següent</a>
    <?php else: ?>
      <span class="disabled">Següent</span>
    <?php endif; ?>
  </div>
</body>
</html>