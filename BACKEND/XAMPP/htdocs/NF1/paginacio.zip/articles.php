<?php 
require_once __DIR__ . '/Controller/Article/paginacio.controller.php';