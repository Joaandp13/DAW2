<?php

require_once __DIR__ . '/../core/db_conn.php';

class Article
{
    private PDO $db;

    public function __construct()
    {
        $this->db = DataBase::getConnexio();
    }

    public function llistarTots(): array
    {
        return $this->db->query('SELECT id, titol, cos FROM articles ORDER BY id')->fetchAll();
    }

    public function cercarPerId(int $id): array|false
    {
        $stmt = $this->db->prepare('SELECT id, titol, cos FROM articles WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function modificarPerId(int $id, array $data): bool
    {
        $stmt = $this->db->prepare('UPDATE articles SET titol = :titol, cos = :cos WHERE id = :id');
        $stmt->execute([
            'id' => $id,
            'titol' => $data['titol'],
            'cos' => $data['cos'],
        ]);

        // rowCount pot ser zero si les dades no han canviat.
        if ($stmt->rowCount() === 0) {
            return $this->cercarPerId($id) !== false;
        }

        return true;
    }

    public function esborrarPerId(int $id): bool
    {
        $stmt = $this->db->prepare('DELETE FROM articles WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }

    public function insertarNouArticle(array $data): int
    {
        $stmt = $this->db->prepare('INSERT INTO articles (titol, cos) VALUES (:titol, :cos)');
        $stmt->execute([
            'titol' => $data['titol'],
            'cos' => $data['cos'],
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function comptarArticles(): int
    {
        return $this->db->query('SELECT COUNT(*) FROM articles')->fetchColumn();
    }

    public function returnPage(int $limit, int $offset) :array
    {
        $stmt = $this->db->prepare('SELECT titol, cos FROM articles ORDER BY id LIMIT :limit OFFSET :offset ');
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}